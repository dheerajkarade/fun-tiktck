package com.ticktocktick.app.Discover;

import com.ticktocktick.app.Home.Home_Get_Set;

import java.util.ArrayList;

/**
 * Created by AQEEL on 3/1/2019.
 */

public class Discover_Get_Set {

    String title,discription;

    ArrayList<Home_Get_Set> arrayList;

}
