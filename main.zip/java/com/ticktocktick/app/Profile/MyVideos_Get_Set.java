package com.ticktocktick.app.Profile;

import java.io.Serializable;

/**
 * Created by AQEEL on 3/4/2019.
 */

public class MyVideos_Get_Set implements Serializable {
    public String fb_id,video_url,thum,gif,created;
}
