package com.ticktocktick.app.Video_Recording.DraftVideos;

public class DraftVideo_Get_Set {
    String video_path,video_time;
    long video_duration_ms;
}
