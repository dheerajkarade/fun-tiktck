package com.ticktocktick.app.SimpleClasses;

public interface Fragment_Data_Send {

    void onDataSent(String yourData);
}
