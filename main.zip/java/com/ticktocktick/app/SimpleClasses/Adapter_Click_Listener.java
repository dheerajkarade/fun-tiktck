package com.ticktocktick.app.SimpleClasses;

import android.view.View;

public interface Adapter_Click_Listener {
    void onItemClick(View view, int pos, Object object);
}
